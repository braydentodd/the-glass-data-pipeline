"""
The Glass - Core synchronization modules
"""
